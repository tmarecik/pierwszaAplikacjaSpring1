package spring.pierwszaAplikacjaSpring.modelMikolaj;

import org.springframework.stereotype.Component;

@Component("lobuz")    //zadeklarowanie innego imienia dla @BEANS'a
public class Mateusz extends Dziecko{



}
