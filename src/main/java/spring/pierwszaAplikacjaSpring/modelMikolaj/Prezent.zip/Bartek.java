package spring.pierwszaAplikacjaSpring.modelMikolaj;

import org.springframework.stereotype.Component;

@Component("milczek")
public class Bartek extends Dziecko{
}
