package spring.pierwszaAplikacjaSpring.modelMikolaj;

import org.springframework.stereotype.Component;

@Component("zlosnica")
public class Klaudia extends Dziecko{
}
