package spring.pierwszaAplikacjaSpring.modelMikolaj;

public class Dziecko {

    public void daj(Prezent prezent){
        prezent.getNazwa();
        System.out.println("Yaya prezent " + prezent.getNazwa());

    }
}
