package spring.pierwszaAplikacjaSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PierwszaAplikacjaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(PierwszaAplikacjaSpringApplication.class, args);
	}

}


