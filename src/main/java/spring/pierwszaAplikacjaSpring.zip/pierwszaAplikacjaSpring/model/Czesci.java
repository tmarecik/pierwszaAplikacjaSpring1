package spring.pierwszaAplikacjaSpring.model;

public interface Czesci {




}
