package spring.pierwszaAplikacjaSpring.model;

import org.springframework.stereotype.Component;

@Component
public class Kola implements Czesci{
}
