package spring.pierwszaAplikacjaSpring.model;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class Kluczyki {
}
